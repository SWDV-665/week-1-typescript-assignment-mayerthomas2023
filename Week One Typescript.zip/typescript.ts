class Grocery {
    
    name:string;
    quantity:number;
    price:number;
// add more attributes here if  needed
    
    constructor(name: string, quantity: number, price: number){
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }
}

//array
const groceries: Grocery[] = [
    new Grocery("milk", 2, 10),
    new Grocery("bread", 5, 35),
    new Grocery("cheese", 11, 25),
    new Grocery("butter", 1, 5)
]
//display items as output of html 
const groceryListElement = document.getElementById('grocery-list');

if (groceryListElement) {
  let html = '<ul>';

  for (const grocery of groceries) {
    html += `<li>${grocery.name}: ${grocery.quantity}: ${grocery.price} </li>`;
  }

  html += '</ul>';

  groceryListElement.innerHTML = html;
}